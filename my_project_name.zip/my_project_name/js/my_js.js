$(document).ready(function () {
    var i = 0;
    var timer;

    //用jquery方法设置第一张图片显示，其余隐藏
    $('.item').eq(0).show().siblings('.item').hide();

    //调用showTime()函数（轮播函数）
    showTime();

    //当鼠标经过下面的数字时，触发两个事件（鼠标悬停和鼠标离开）
    $('.tab').hover(function () {
        //获取当前i的值，并显示，同时还要清除定时器
        i = $(this).index();
        Show();
        clearInterval(timer);
    }, function () {
        showTime();
    });
    //当鼠标经过轮播图时，触发两个事件（鼠标悬停和鼠标离开）
    $('.item').hover(function () {
        //清除定时器
        clearInterval(timer);
    }, function () {
        showTime();
    });

    //鼠标点击左侧的箭头
    $('.prev').click(function () {
        clearInterval(timer);
        if (i == 0) {
            i = 5; //注意此时i的值
        }
        i--;
        Show();
        showTime();
    });

    //鼠标点击右侧的箭头
    $('.next').click(function () {
        clearInterval(timer);
        if (i == 4) {
            i = -1; //注意此时i的值
        }
        i++;
        Show();
        showTime();
    });


    //创建一个showTime函数
    function showTime() {
        //定时器
        timer = setInterval(function () {
            //调用一个Show()函数
            Show();
            i++;
            //当图片是最后一张的后面时，设置图片为第一张
            if (i == 5) {
                i = 0;
            }
        }, 2000);
    }


    //创建一个Show函数
    function Show() {
        //在这里可以用其他jquery的动画
        $('.item').eq(i).fadeIn(300).siblings('.item').fadeOut(300);

        //给.tab创建一个新的Class为其添加一个新的样式，并且要在css代码中设置该样式
        $('.tab').eq(i).addClass('active').siblings('.tab').removeClass('active');

    }
    var myChart = echarts.init(document.querySelector('.diagram'));
    var option = {
        title: {
            text: '曲线图数据展示',
            left: 'center'
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
            }
        },
        xAxis: [{
            type: 'category',
            boundaryGap: false,
            data: ['01/26', '01/28', '01/30', '02/01', '02/03', '02/05', '02/07', '02/09', '02/11',
                '02/13', '02/15', '02/17', '02/19', '02/21', '02/23'
            ]
        }],
        yAxis: [{
            type: 'value',
            axisLabel: {
                formatter: '{value}人'
            }
        }],
        series: [{
            type: 'line',
            smooth: true,
            label: {
                normal: {
                    color: '#4d8bf1',
                    show: true,
                    position: 'top'
                }
            },
            areaStyle: {},
            data: [8972, 6448, 7456, 5824, 8123, 300, 300, 5319, 7463, 1435, 9426, 8187, 8297, 443,
                9135
            ]
        }]
    };

    myChart.setOption(option);
    var myChart = echarts.init(document.querySelector('.pie_chart'));
    var option = {
        title: {
            text: '饼状图数据展示',
            left: 'center'
        },
        series: [{
            type: 'pie',
            radius: '60%',
            center: ['50%', '50%'],
            data: [{
                    value: 335,
                    name: 'Mon'
                },
                {
                    value: 310,
                    name: 'Tue'
                },
                {
                    value: 234,
                    name: 'Wed'
                },
                {
                    value: 135,
                    name: 'Thu'
                },
                {
                    value: 1848,
                    name: 'Fri'
                },
                {
                    value: 1548,
                    name: 'Sat'
                },
                {
                    value: 1548,
                    name: 'Sun'
                }
            ],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }]
    };

    myChart.setOption(option);
    var myChart = echarts.init(document.querySelector('.histogram'));
    var option = {
        title: {
            text: '柱状图数据展示',
            left: 'center'
        },
        color: ['#3398DB'],
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        xAxis: [{
            type: 'category',
            data: ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'],
            axisTick: {
                alignWithLabel: true
            }
        }],
        yAxis: [{
            name: '商品数',
            type: 'value'
        }],
        series: [{
            type: 'bar',
            barWidth: '15px',
            data: [9, 11, 13, 10, 8, 11, 5]
        }]
    };

    myChart.setOption(option);

});